import { Trophy, Star } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface LeaderboardApp {
  name: string;
  category: string;
  rating: number;
  reviews: number;
}

interface LeaderboardProps {
  apps: LeaderboardApp[];
}

export const Leaderboard = ({ apps }: LeaderboardProps) => {
  const topApps = [...apps].sort((a, b) => b.rating - a.rating).slice(0, 5);

  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Trophy className="h-6 w-6 text-accent" />
          <CardTitle className="text-2xl font-bold">Top Applications</CardTitle>
        </div>
      </CardHeader>

      <CardContent>
        <div className="space-y-4">
          {topApps.map((app, index) => (
            <div
              key={app.name}
              className="flex items-center justify-between p-4 rounded-lg border border-border bg-secondary/80 hover:bg-secondary transition-all shadow-sm hover:shadow-md"
            >
              <div className="flex items-center gap-4">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold text-sm">
                  {index + 1}
                </div>
                <div>
                  <p className="font-semibold text-foreground">{app.name}</p>
                  <p className="text-sm text-muted-foreground">{app.category}</p>
                </div>
              </div>

              <div className="flex flex-col items-end gap-1">
                <div className="flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, i) => {
                    const isFilled = i < app.rating;
                    return (
                      <Star
                        key={i}
                        className={`h-4 w-4 transition-transform duration-200 ${
                          isFilled
                            ? "fill-yellow-400 text-yellow-400 hover:scale-110"
                            : "fill-muted text-muted"
                        }`}
                        style={
                          isFilled
                            ? {
                                filter:
                                  "drop-shadow(0 0 4px rgba(255, 230, 120, 0.9)) drop-shadow(0 0 8px rgba(255, 200, 80, 0.5))",
                              }
                            : {}
                        }
                      />
                    );
                  })}
                </div>
                <span className="text-[13px] font-medium text-foreground/80">
                  ({app.reviews} reviews)
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
