import { ExternalLink, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import agentIcon from "@/assets/category-agent.png";
import analyticsIcon from "@/assets/category-analytics.png";
import verificationIcon from "@/assets/category-verification.png";
import templateIcon from "@/assets/category-template.png";

const categoryIcons: Record<string, string> = {
  Agent: agentIcon,
  Analytics: analyticsIcon,
  Verification: verificationIcon,
  Template: templateIcon,
};

interface AppCardProps {
  name: string;
  description: string;
  category: string;
  demoLink: string;
  rating: number;
  reviews: number;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}

export const AppCard = ({ name, description, category, demoLink, rating, reviews, isFavorite, onToggleFavorite }: AppCardProps) => {
  const categoryIcon = categoryIcons[category] || agentIcon;
  
  return (
    <Card className="group hover:shadow-[var(--shadow-glow)] transition-all duration-300 border-border bg-card h-full flex flex-col">
      <CardHeader>
        <div className="flex items-center gap-4 mb-4">
          <img 
            src={categoryIcon} 
            alt={`${category} icon`}
            className="w-16 h-16 rounded-lg object-cover"
          />
          <div className="flex items-center gap-2 ml-auto shrink-0">
            <Badge variant="secondary">
              {category}
            </Badge>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={onToggleFavorite}
            >
              <Star
  className={`h-5 w-5 transition-colors duration-200 ${
    isFavorite
      ? "fill-yellow-400 text-yellow-400 hover:scale-110" // bright golden-yellow
      : "text-muted-foreground"
  }`}
  style={
    isFavorite
      ? {
          filter:
            "drop-shadow(0 0 4px rgba(255, 230, 120, 0.8)) drop-shadow(0 0 8px rgba(255, 200, 80, 0.5))",
        }
      : {}
  }
/>
            </Button>
          </div>
        </div>
        <CardTitle className="text-xl font-bold text-foreground group-hover:text-primary transition-colors mb-2">
          {name}
        </CardTitle>
        <div className="flex items-center gap-2 mb-2">
          <div className="flex items-center gap-1">
            {Array.from({ length: 5 }).map((_, i) => (
             <Star
  key={i}
  className={`h-4 w-4 transition-transform duration-200 ${
    i < rating
      ? "fill-yellow-400 text-yellow-400 hover:scale-110"
      : "fill-muted text-muted"
  }`}
  style={
    i < rating
      ? {
          filter:
            "drop-shadow(0 0 4px rgba(255, 230, 120, 0.9)) drop-shadow(0 0 8px rgba(255, 200, 80, 0.5))",
        }
      : {}
  }
/>
            ))}
          </div>
          <span className="text-sm text-muted-foreground">({reviews} reviews)</span>
        </div>
        <CardDescription className="text-muted-foreground line-clamp-2">
          {description}
        </CardDescription>
      </CardHeader>
      <CardFooter className="mt-auto pt-0">
        <Button
          asChild
          className="w-full font-semibold group-hover:shadow-[var(--shadow-glow)] transition-all"
        >
          <a href={demoLink} target="_blank" rel="noopener noreferrer">
            Try Now
            <ExternalLink className="ml-2 h-4 w-4" />
          </a>
        </Button>
      </CardFooter>
    </Card>
  );
};
