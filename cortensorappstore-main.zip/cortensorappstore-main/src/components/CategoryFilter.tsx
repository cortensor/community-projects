import { Button } from "@/components/ui/button";

interface CategoryFilterProps {
  categories: string[];
  activeCategory: string | null;
  onCategoryChange: (category: string | null) => void;
}

export const CategoryFilter = ({
  categories,
  activeCategory,
  onCategoryChange,
}: CategoryFilterProps) => {
  return (
    <div className="flex flex-wrap gap-3">
      <Button
        variant={activeCategory === null ? "default" : "secondary"}
        onClick={() => onCategoryChange(null)}
        className="font-semibold"
      >
        All Apps
      </Button>
      {categories.map((category) => (
        <Button
          key={category}
          variant={activeCategory === category ? "default" : "secondary"}
          onClick={() => onCategoryChange(category)}
          className="font-semibold"
        >
          {category}
        </Button>
      ))}
    </div>
  );
};
