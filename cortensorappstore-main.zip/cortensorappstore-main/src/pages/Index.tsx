import { useState, useMemo, useEffect } from "react";
import { SearchBar } from "@/components/SearchBar";
import { CategoryFilter } from "@/components/CategoryFilter";
import { AppCard } from "@/components/AppCard";
import appsData from "@/data/apps.json";
import { Layers, Trophy } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const Index = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);

  useEffect(() => {
    const savedFavorites = localStorage.getItem("cortensor-favorites");
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
  }, []);

  const toggleFavorite = (appId: string) => {
    setFavorites((prev) => {
      const newFavorites = prev.includes(appId)
        ? prev.filter((id) => id !== appId)
        : [...prev, appId];
      localStorage.setItem("cortensor-favorites", JSON.stringify(newFavorites));
      return newFavorites;
    });
  };

  const categories = useMemo(
    () => ["Agent", "Analytics", "Verification", "Template"],
    []
  );

  const filteredApps = useMemo(() => {
    return appsData.filter((app) => {
      const matchesSearch = app.name
        .toLowerCase()
        .includes(searchQuery.toLowerCase());
      const matchesCategory =
        !activeCategory || app.category === activeCategory;
      const matchesFavorites = !showFavoritesOnly || favorites.includes(app.id);
      return matchesSearch && matchesCategory && matchesFavorites;
    });
  }, [searchQuery, activeCategory, showFavoritesOnly, favorites]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/95 backdrop-blur-md sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Layers className="h-8 w-8 text-primary" />
                <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                  Cortensor App Store
                </h1>
              </div>
              <p className="text-muted-foreground">
                Discover and deploy cutting-edge AI applications
              </p>
            </div>
            <Button asChild variant="outline">
              <Link to="/leaderboard" className="flex items-center gap-2">
                <Trophy className="h-4 w-4" />
                Leaderboard
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Search and Filter Section */}
        <div className="mb-12 space-y-6">
          <SearchBar value={searchQuery} onChange={setSearchQuery} />
          <div className="space-y-4">
            <CategoryFilter
              categories={categories}
              activeCategory={activeCategory}
              onCategoryChange={setActiveCategory}
            />
            <Button
              variant={showFavoritesOnly ? "default" : "secondary"}
              onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
              className="font-semibold"
            >
              ⭐ Favorites {favorites.length > 0 && `(${favorites.length})`}
            </Button>
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold text-foreground mb-6">
            Applications
            <span className="ml-2 text-muted-foreground text-lg">
              ({filteredApps.length})
            </span>
          </h2>
          {filteredApps.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredApps.map((app) => (
                <AppCard
                  key={app.id}
                  name={app.name}
                  description={app.description}
                  category={app.category}
                  demoLink={app.demoLink}
                  rating={app.rating}
                  reviews={app.reviews}
                  isFavorite={favorites.includes(app.id)}
                  onToggleFavorite={() => toggleFavorite(app.id)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-lg">
                No applications found matching your criteria.
              </p>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 mt-16">
        <div className="container mx-auto px-4 py-6 text-center">
          <p className="text-muted-foreground">
            © 2025 Cortensor. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
