# ⚡ Cortensor App Store Dashboard

A modern and elegant **AI App Store Dashboard** built with React + Vite.  
Discover, filter, and explore AI-powered applications across categories like **Agents, Analytics, Verification**, and **Templates** — all within a smooth, responsive UI.



---

## 🚀 Features

- 🧠 **App Discovery** – Browse curated AI apps with name, category, rating, and reviews.  
- 🌈 **Dynamic Leaderboard** – Highlights top-rated applications with star ratings.  
- 🔍 **Smart Filtering** – View apps by category for quick exploration.  
- 💳 **App Details Page (optional)** – Extendable to show app info, demo link, and deploy options.  
- 💫 **Polished UI** – Built with **TailwindCSS** and **shadcn/ui** components.  
- 🌐 **Fast Build System** – Powered by **Vite + SWC** for lightning-fast reloads.  

---

## 🛠️ Tech Stack

| Layer | Tools / Libraries |
|-------|--------------------|
| **Frontend** | React (TypeScript) |
| **Build Tool** | Vite |
| **Styling** | TailwindCSS + shadcn/ui |
| **Icons** | Lucide Icons |
| **UI Enhancements** | Framer Motion (animations) |